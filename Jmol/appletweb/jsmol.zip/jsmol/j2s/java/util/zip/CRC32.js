Clazz.declarePackage ("java.util.zip");
Clazz.load (["JZ.CRC32"], "java.util.zip.CRC32", null, function () {
c$ = Clazz.declareType (java.util.zip, "CRC32", JZ.CRC32);
});
