docmd("rotate x 30;;",0.2512171)
