$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.SimpleSerializable"],"net.sf.j2s.ajax.SimplePipeSequence",null,function(){
c$=$_C(function(){
this.sequence=0;
$_Z(this,arguments);
},net.sf.j2s.ajax,"SimplePipeSequence",net.sf.j2s.ajax.SimpleSerializable);
$_s(c$,"sequence","L");
});
