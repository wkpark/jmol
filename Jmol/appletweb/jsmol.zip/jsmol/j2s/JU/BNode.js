Clazz.declarePackage ("JU");
Clazz.load (["JU.Node"], "JU.BNode", null, function () {
Clazz.declareInterface (JU, "BNode", JU.Node);
});
