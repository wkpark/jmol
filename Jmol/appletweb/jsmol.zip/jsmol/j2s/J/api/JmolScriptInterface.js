Clazz.declarePackage ("J.api");
Clazz.load (["J.api.JmolSyncInterface"], "J.api.JmolScriptInterface", null, function () {
Clazz.declareInterface (J.api, "JmolScriptInterface", J.api.JmolSyncInterface);
});
