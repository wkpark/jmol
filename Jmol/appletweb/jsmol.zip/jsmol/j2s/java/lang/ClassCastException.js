$_L(["java.lang.RuntimeException"],"java.lang.ClassCastException",null,function(){
c$=$_T(java.lang,"ClassCastException",RuntimeException);
});
