﻿c$=$_C(function(){
this.types=null;
this.points=null;
$_Z(this,arguments);
},$wt.graphics,"PathData");
