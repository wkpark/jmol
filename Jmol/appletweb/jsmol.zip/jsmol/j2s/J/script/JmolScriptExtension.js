Clazz.declarePackage ("J.script");
Clazz.declareInterface (J.script, "JmolScriptExtension");
