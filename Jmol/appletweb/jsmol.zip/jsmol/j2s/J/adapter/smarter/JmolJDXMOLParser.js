Clazz.declarePackage ("J.adapter.smarter");
Clazz.declareInterface (J.adapter.smarter, "JmolJDXMOLParser");
