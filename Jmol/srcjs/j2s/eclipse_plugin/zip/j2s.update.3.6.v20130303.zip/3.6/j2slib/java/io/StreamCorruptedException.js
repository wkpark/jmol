﻿$_L(["java.io.ObjectStreamException"],"java.io.StreamCorruptedException",null,function(){
c$=$_T(java.io,"StreamCorruptedException",java.io.ObjectStreamException);
});
