$_L(["java.io.IOException"],"java.util.InvalidPropertiesFormatException",["java.io.NotSerializableException"],function(){
c$=$_T(java.util,"InvalidPropertiesFormatException",java.io.IOException);
$_K(c$,
function(c){
$_R(this,java.util.InvalidPropertiesFormatException,[]);
this.initCause(c);
},"Throwable");
});
