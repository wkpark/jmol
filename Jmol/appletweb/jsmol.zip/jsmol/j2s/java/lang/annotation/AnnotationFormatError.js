$_L(["java.lang.Error"],"java.lang.annotation.AnnotationFormatError",null,function(){
c$=$_T(java.lang.annotation,"AnnotationFormatError",Error);
$_K(c$,
function(cause){
$_R(this,java.lang.annotation.AnnotationFormatError,[cause==null?null:cause.toString(),cause]);
},"Throwable");
});
