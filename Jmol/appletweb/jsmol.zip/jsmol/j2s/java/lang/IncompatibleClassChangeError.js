$_L(["java.lang.LinkageError"],"java.lang.IncompatibleClassChangeError",null,function(){
c$=$_T(java.lang,"IncompatibleClassChangeError",LinkageError);
});
