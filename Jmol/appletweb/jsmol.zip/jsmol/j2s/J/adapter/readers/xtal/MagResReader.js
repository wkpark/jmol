Clazz.declarePackage ("J.adapter.readers.xtal");
Clazz.load (["J.adapter.smarter.AtomSetCollectionReader", "java.util.Hashtable"], "J.adapter.readers.xtal.MagResReader", ["J.adapter.smarter.Atom", "J.util.Eigen", "$.TextFormat"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cellParams = null;
this.maxIso = 10000;
this.tensorTypes = "";
this.isNew = false;
this.mapUnits = null;
this.atom = null;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.xtal, "MagResReader", J.adapter.smarter.AtomSetCollectionReader);
Clazz.prepareFields (c$, function () {
this.mapUnits =  new java.util.Hashtable ();
});
Clazz.overrideMethod (c$, "initializeReader", 
function () {
this.setFractionalCoordinates (false);
this.doApplySymmetry = false;
this.atomSetCollection.newAtomSet ();
});
Clazz.overrideMethod (c$, "finalizeReader", 
function () {
this.doApplySymmetry = true;
this.finalizeReaderASCR ();
});
Clazz.overrideMethod (c$, "checkLine", 
function () {
if (!this.isNew && this.line.indexOf ("<calculation>") >= 0) {
this.isNew = true;
this.ignoreFileSpaceGroupName = true;
}if (this.cellParams == null && this.line.startsWith ("lattice")) {
this.readCellParams ();
return true;
}if (this.isNew) {
if (this.line.startsWith ("units")) {
this.setUnitsNew ();
} else if (this.line.startsWith ("atom")) {
this.readAtom (true);
this.atom.ellipsoid =  new Array (2);
} else if (this.line.startsWith ("symmetry")) {
this.readSymmetryNew ();
} else if (this.line.startsWith ("ms")) {
this.readTensorNew (0);
} else if (this.line.startsWith ("efg")) {
this.readTensorNew (1);
} else if (this.line.startsWith ("<magres_old>")) {
this.continuing = false;
}return true;
}if (this.line.contains ("Coordinates")) {
this.readAtom (false);
} else if (this.line.contains ("J-coupling Total") || this.line.contains ("TOTAL tensor")) {
this.readTensorOld ();
}return true;
});
$_M(c$, "readTensorNew", 
($fz = function (iType) {
var data =  Clazz.newFloatArray (9, 0);
var tokens = this.getTokens ();
var atomName = (tokens[1] + tokens[2]);
this.fillFloatArray (this.line.substring (30), 0, data);
var f = (iType == 0 ? 0.04 : 1);
var a =  Clazz.newDoubleArray (3, 3, 0);
for (var i = 0, pt = 0; i < 3; i++) for (var j = 0; j < 3; j++) a[i][j] = data[pt++];


this.atom = this.atomSetCollection.getAtoms ()[this.atomSetCollection.getAtomIndexFromName (atomName)];
this.atom.ellipsoid[iType] = J.util.Eigen.getEllipsoidDD (a);
this.atom.ellipsoid[iType].scale (f);
if (this.tensorTypes.indexOf ("" + iType) < 0) {
this.tensorTypes += "" + iType;
this.appendLoadNote ("Ellipsoids set " + (iType + 1) + ": " + (iType == 0 ? "Magnetic Shielding" : "Electric Field Gradient"));
}}, $fz.isPrivate = true, $fz), "~N");
$_M(c$, "readSymmetryNew", 
($fz = function () {
this.setSymmetryOperator (this.getTokens ()[1]);
}, $fz.isPrivate = true, $fz));
$_M(c$, "setUnitsNew", 
($fz = function () {
var tokens = this.getTokens ();
this.mapUnits.put (tokens[1], tokens[2]);
}, $fz.isPrivate = true, $fz));
$_M(c$, "readCellParams", 
($fz = function () {
var tokens = this.getTokens ();
this.cellParams =  Clazz.newFloatArray (9, 0);
for (var i = 0; i < 9; i++) this.cellParams[i] = this.parseFloatStr (tokens[i + 1]) * 0.5291772;

this.addPrimitiveLatticeVector (0, this.cellParams, 0);
this.addPrimitiveLatticeVector (1, this.cellParams, 3);
this.addPrimitiveLatticeVector (2, this.cellParams, 6);
this.setSpaceGroupName ("P1");
}, $fz.isPrivate = true, $fz));
$_M(c$, "readAtom", 
($fz = function (isNew) {
var f = ((isNew ? this.mapUnits.get ("atom").startsWith ("A") : this.line.trim ().endsWith ("A")) ? 1 : 0.5291772);
var pt = (isNew ? 2 : 0);
var tokens = this.getTokens ();
this.atom =  new J.adapter.smarter.Atom ();
this.atom.elementSymbol = tokens[pt];
this.atom.atomName = tokens[pt++] + tokens[pt++];
this.atomSetCollection.addAtomWithMappedName (this.atom);
if (!isNew) pt++;
var x = this.parseFloatStr (tokens[pt++]) * f;
var y = this.parseFloatStr (tokens[pt++]) * f;
var z = this.parseFloatStr (tokens[pt++]) * f;
this.atom.set (x, y, z);
this.setAtomCoord (this.atom);
}, $fz.isPrivate = true, $fz), "~B");
$_M(c$, "readTensorOld", 
($fz = function () {
this.line = this.line.trim ();
if (this.tensorTypes.indexOf (this.line) < 0) {
this.tensorTypes += this.line;
this.appendLoadNote ("Ellipsoids: " + this.line);
}this.atomSetCollection.setAtomSetName (this.line);
var isJ = (this.line.indexOf ("J-") >= 0);
var data =  Clazz.newFloatArray (9, 0);
this.readLine ();
var s = J.util.TextFormat.simpleReplace (this.readLine () + this.readLine () + this.readLine (), "-", " -");
this.fillFloatArray (s, 0, data);
var f = 3;
if (isJ) {
this.discardLinesUntilContains ("Isotropic");
var iso = this.parseFloatStr (this.getTokens ()[3]);
if (Math.abs (iso) > this.maxIso) return;
f = 0.04;
}var a =  Clazz.newDoubleArray (3, 3, 0);
for (var i = 0, pt = 0; i < 3; i++) for (var j = 0; j < 3; j++) a[i][j] = data[pt++];


this.atom.setEllipsoid (J.util.Eigen.getEllipsoidDD (a));
this.atom.ellipsoid[0].scale (f);
}, $fz.isPrivate = true, $fz));
});
