$_L(["java.lang.ClassFormatError"],"java.lang.UnsupportedClassVersionError",null,function(){
c$=$_T(java.lang,"UnsupportedClassVersionError",ClassFormatError);
});
