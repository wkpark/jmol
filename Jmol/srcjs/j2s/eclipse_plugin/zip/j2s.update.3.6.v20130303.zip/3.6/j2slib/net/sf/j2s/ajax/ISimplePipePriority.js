﻿$_J("net.sf.j2s.ajax");
c$=$_I(net.sf.j2s.ajax,"ISimplePipePriority");
$_S(c$,
"IMPORTANT",32,
"NORMAL",8,
"TRIVIAL",1);
