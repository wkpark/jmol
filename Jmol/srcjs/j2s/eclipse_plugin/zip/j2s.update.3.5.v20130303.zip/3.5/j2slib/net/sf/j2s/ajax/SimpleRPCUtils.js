$_J("net.sf.j2s.ajax");
c$=$_T(net.sf.j2s.ajax,"SimpleRPCUtils");
