﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.MouseListener",null,function(){
$_I($wt.events,"MouseListener",$wt.internal.SWTEventListener);
});
