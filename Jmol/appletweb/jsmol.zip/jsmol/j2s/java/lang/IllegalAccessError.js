$_L(["java.lang.IncompatibleClassChangeError"],"java.lang.IllegalAccessError",null,function(){
c$=$_T(java.lang,"IllegalAccessError",IncompatibleClassChangeError);
});
