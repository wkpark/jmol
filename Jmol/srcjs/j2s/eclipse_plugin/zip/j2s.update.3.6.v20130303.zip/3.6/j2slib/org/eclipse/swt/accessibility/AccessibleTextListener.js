﻿$_L(["$wt.internal.SWTEventListener"],"$wt.accessibility.AccessibleTextListener",null,function(){
$_I($wt.accessibility,"AccessibleTextListener",$wt.internal.SWTEventListener);
});
