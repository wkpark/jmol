Clazz.declarePackage ("J.adapter.readers.xtal");
Clazz.load (["J.adapter.smarter.AtomSetCollectionReader", "java.util.Hashtable", "J.util.JmolList"], "J.adapter.readers.xtal.MagResReader", ["java.lang.Double", "J.adapter.smarter.Atom", "J.util.Tensor", "$.TextFormat"], function () {
c$ = Clazz.decorateAsClass (function () {
this.cellParams = null;
this.tensorTypes = "";
this.isNew = false;
this.mapUnits = null;
this.interactionTensors = null;
this.atom = null;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.xtal, "MagResReader", J.adapter.smarter.AtomSetCollectionReader);
Clazz.prepareFields (c$, function () {
this.mapUnits =  new java.util.Hashtable ();
this.interactionTensors =  new J.util.JmolList ();
});
Clazz.overrideMethod (c$, "initializeReader", 
function () {
this.setFractionalCoordinates (false);
this.doApplySymmetry = false;
this.atomSetCollection.newAtomSet ();
try {
this.readLine ();
this.isNew = this.line.startsWith ("#$magres");
if (this.isNew) {
this.ignoreFileSpaceGroupName = true;
}} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
} else {
throw e;
}
}
});
Clazz.overrideMethod (c$, "finalizeReader", 
function () {
this.doApplySymmetry = true;
this.finalizeReaderASCR ();
if (this.interactionTensors.size () > 0) this.atomSetCollection.setAtomSetAuxiliaryInfo ("interactionTensors", this.interactionTensors);
});
Clazz.overrideMethod (c$, "checkLine", 
function () {
if (this.cellParams == null && this.line.startsWith ("lattice")) {
this.readCellParams ();
return true;
}if (this.isNew) {
if (this.line.startsWith ("units")) {
this.setUnitsNew ();
} else if (this.line.startsWith ("atom")) {
this.readAtom (true);
} else if (this.line.startsWith ("symmetry")) {
this.readSymmetryNew ();
} else if (this.line.startsWith ("ms") || this.line.startsWith ("efg") || this.line.startsWith ("isc")) {
this.readTensorNew ();
} else if (this.line.startsWith ("<magres_old>")) {
this.continuing = false;
}return true;
}if (this.line.contains ("Coordinates")) {
this.readAtom (false);
} else if (this.line.contains ("J-coupling Total") || this.line.contains ("TOTAL tensor") || this.line.contains ("TOTAL Shielding Tensor")) {
this.readTensorOld ();
}return true;
});
$_M(c$, "readTensorNew", 
($fz = function () {
var tokens = this.getTokens ();
var id = tokens[0];
var pt = id.indexOf ("_");
var type = (pt < 0 ? id : id.substring (0, pt));
var atomName1 = this.getAtomName (tokens[1], tokens[2]);
pt = 3;
var atomName2 = (type.equals ("isc") ? this.getAtomName (tokens[pt++], tokens[pt++]) : null);
var a =  Clazz.newDoubleArray (3, 3, 0);
for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) a[i][j] = Double.$valueOf (tokens[pt++]).doubleValue ();


var index1 = this.atomSetCollection.getAtomIndexFromName (atomName1);
var index2;
var t = J.util.Tensor.getTensorFromAsymmetricTensor (a, type);
if (atomName2 == null) {
index2 = -1;
this.atomSetCollection.getAtoms ()[index1].addTensor (t, null);
this.interactionTensors.addLast (t);
} else {
index2 = this.atomSetCollection.getAtomIndexFromName (atomName2);
}t.setAtomIndexes (index1, index2);
if (this.tensorTypes.indexOf (type) < 0) {
this.tensorTypes += type;
this.appendLoadNote ("Ellipsoids set \"" + type + "\": " + (type.equals ("ms") ? "Magnetic Shielding" : type.equals ("efg") ? "Electric Field Gradient" : type.equals ("isc") ? "Coupling" : "?"));
}}, $fz.isPrivate = true, $fz));
$_M(c$, "readSymmetryNew", 
($fz = function () {
this.setSymmetryOperator (this.getTokens ()[1]);
}, $fz.isPrivate = true, $fz));
$_M(c$, "setUnitsNew", 
($fz = function () {
var tokens = this.getTokens ();
this.mapUnits.put (tokens[1], tokens[2]);
}, $fz.isPrivate = true, $fz));
$_M(c$, "readCellParams", 
($fz = function () {
var tokens = this.getTokens ();
this.cellParams =  Clazz.newFloatArray (9, 0);
for (var i = 0; i < 9; i++) this.cellParams[i] = this.parseFloatStr (tokens[i + 1]) * 0.5291772;

this.addPrimitiveLatticeVector (0, this.cellParams, 0);
this.addPrimitiveLatticeVector (1, this.cellParams, 3);
this.addPrimitiveLatticeVector (2, this.cellParams, 6);
this.setSpaceGroupName ("P1");
}, $fz.isPrivate = true, $fz));
$_M(c$, "readAtom", 
($fz = function (isNew) {
var f = ((isNew ? this.mapUnits.get ("atom").startsWith ("A") : this.line.trim ().endsWith ("A")) ? 1 : 0.5291772);
var tokens = this.getTokens ();
this.atom =  new J.adapter.smarter.Atom ();
var pt = (isNew ? 1 : 0);
this.atom.elementSymbol = tokens[isNew ? pt++ : pt];
this.atom.atomName = this.getAtomName (tokens[pt++], tokens[pt++]);
this.atomSetCollection.addAtomWithMappedName (this.atom);
if (!isNew) pt++;
var x = this.parseFloatStr (tokens[pt++]) * f;
var y = this.parseFloatStr (tokens[pt++]) * f;
var z = this.parseFloatStr (tokens[pt++]) * f;
this.atom.set (x, y, z);
this.setAtomCoord (this.atom);
}, $fz.isPrivate = true, $fz), "~B");
$_M(c$, "getAtomName", 
($fz = function (name, index) {
return name + (name.indexOf ("_") >= 0 ? "_" : "") + index;
}, $fz.isPrivate = true, $fz), "~S,~S");
$_M(c$, "readTensorOld", 
($fz = function () {
this.line = this.line.trim ();
if (this.tensorTypes.indexOf (this.line) < 0) {
this.tensorTypes += this.line;
this.appendLoadNote ("Ellipsoids: " + this.line);
}this.atomSetCollection.setAtomSetName (this.line);
var type = (this.line.indexOf ("J-") >= 0 ? "isc" : this.line.indexOf ("Shielding") >= 0 ? "ms" : "efg");
var data =  Clazz.newFloatArray (9, 0);
this.readLine ();
var s = J.util.TextFormat.simpleReplace (this.readLine () + this.readLine () + this.readLine (), "-", " -");
this.fillFloatArray (s, 0, data);
if (type.equals ("isc")) {
this.discardLinesUntilContains ("Isotropic");
var iso = this.parseFloatStr (this.getTokens ()[3]);
if (Math.abs (iso) > J.adapter.readers.xtal.MagResReader.maxIso) return;
}var a =  Clazz.newDoubleArray (3, 3, 0);
for (var i = 0, pt = 0; i < 3; i++) for (var j = 0; j < 3; j++) a[i][j] = data[pt++];


this.atom.addTensor (J.util.Tensor.getTensorFromAsymmetricTensor (a, type), null);
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"maxIso", 10000);
});
