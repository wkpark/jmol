$_L(["java.lang.Exception"],"java.lang.CloneNotSupportedException",null,function(){
c$=$_T(java.lang,"CloneNotSupportedException",Exception);
});
