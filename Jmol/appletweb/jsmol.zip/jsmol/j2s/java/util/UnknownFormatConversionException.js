$_L(["java.util.IllegalFormatException"],"java.util.UnknownFormatConversionException",null,function(){
c$=$_C(function(){
this.s=null;
$_Z(this,arguments);
},java.util,"UnknownFormatConversionException",java.util.IllegalFormatException);
$_K(c$,
function(s){
$_R(this,java.util.UnknownFormatConversionException,[]);
this.s=s;
},"~S");
$_M(c$,"getConversion",
function(){
return this.s;
});
$_V(c$,"getMessage",
function(){
return"Conversion = '"+this.s+"'";
});
});
