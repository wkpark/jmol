Clazz.declarePackage ("J.adapter.readers.pymol");
Clazz.load (["J.adapter.readers.cifpdb.PdbReader", "java.util.Hashtable", "J.util.BS", "$.JmolList", "$.P3"], "J.adapter.readers.pymol.PyMOLReader", ["java.lang.Boolean", "$.Character", "$.Double", "$.Float", "J.adapter.readers.pymol.JmolObject", "$.PickleReader", "$.PyMOL", "$.PyMOLAtom", "$.PyMOLGroup", "J.adapter.smarter.Bond", "$.Structure", "J.atomdata.RadiusData", "J.constant.EnumStructure", "$.EnumVdw", "J.modelset.MeasurementData", "$.Text", "J.util.ArrayUtil", "$.BSUtil", "$.BoxInfo", "$.C", "$.ColorUtil", "$.Escape", "$.Logger", "$.Parser", "$.Point3fi", "$.SB", "$.TextFormat"], function () {
c$ = Clazz.decorateAsClass (function () {
this.allowSurface = true;
this.doResize = false;
this.doCache = false;
this.settings = null;
this.localSettings = null;
this.atomCount0 = 0;
this.$atomCount = 0;
this.stateCount = 0;
this.surfaceCount = 0;
this.structureCount = 0;
this.isHidden = false;
this.pymolAtoms = null;
this.bsHidden = null;
this.bsNucleic = null;
this.bsStructureDefined = null;
this.bsExcluded = null;
this.haveTraceOrBackbone = false;
this.haveNucleicLadder = false;
this.atomMap = null;
this.ssMapSeq = null;
this.ssMapAtom = null;
this.htSpacefill = null;
this.occludedBranches = null;
this.atomColorList = null;
this.labels = null;
this.frameObj = null;
this.jmolObjects = null;
this.colixes = null;
this.isStateScript = false;
this.valence = false;
this.xyzMin = null;
this.xyzMax = null;
this.nModels = 0;
this.logging = false;
this.reps = null;
this.cartoonTranslucency = 0;
this.sphereTranslucency = 0;
this.stickTranslucency = 0;
this.cartoonLadderMode = false;
this.cartoonRockets = false;
this.surfaceMode = 0;
this.surfaceColor = 0;
this.bgRgb = 0;
this.labelFontId = 0;
this.isMovie = false;
this.htNames = null;
this.pymolFrame = 0;
this.pymolState = 0;
this.allStates = false;
this.totalAtomCount = 0;
this.pymolVersion = 0;
this.trajectoryStep = null;
this.trajectoryPtr = 0;
this.branchName = null;
this.branchNameID = null;
this.bsModelAtoms = null;
this.nonBondedSize = 0;
this.sphereScale = 0;
this.selections = null;
this.uniqueSettings = null;
this.labelPosition = null;
this.labelColor = 0;
this.labelSize = 0;
this.labelPosition0 = null;
this.volumeData = null;
this.mapObjects = null;
this.branchIDs = null;
this.groups = null;
this.haveMeasurements = false;
this.frames = null;
this.mepList = "";
this.bsCarb = null;
Clazz.instantialize (this, arguments);
}, J.adapter.readers.pymol, "PyMOLReader", J.adapter.readers.cifpdb.PdbReader);
Clazz.prepareFields (c$, function () {
this.bsHidden =  new J.util.BS ();
this.bsNucleic =  new J.util.BS ();
this.bsStructureDefined =  new J.util.BS ();
this.htSpacefill =  new java.util.Hashtable ();
this.occludedBranches =  new java.util.Hashtable ();
this.atomColorList =  new J.util.JmolList ();
this.jmolObjects =  new J.util.JmolList ();
this.xyzMin = J.util.P3.new3 (1e6, 1e6, 1e6);
this.xyzMax = J.util.P3.new3 (-1000000.0, -1000000.0, -1000000.0);
this.reps =  new Array (15);
this.htNames =  new java.util.Hashtable ();
this.bsModelAtoms = J.util.BS.newN (1000);
this.labelPosition0 =  new J.util.P3 ();
this.branchIDs =  new java.util.Hashtable ();
});
$_M(c$, "initializeReader", 
function () {
this.isBinary = true;
this.isStateScript = this.htParams.containsKey ("isStateScript");
this.atomSetCollection.setAtomSetCollectionAuxiliaryInfo ("noAutoBond", Boolean.TRUE);
this.atomSetCollection.setAtomSetAuxiliaryInfo ("pdbNoHydrogens", Boolean.TRUE);
this.atomSetCollection.setAtomSetCollectionAuxiliaryInfo ("isPyMOL", Boolean.TRUE);
if (this.isTrajectory) this.trajectorySteps =  new J.util.JmolList ();
Clazz.superCall (this, J.adapter.readers.pymol.PyMOLReader, "initializeReader", []);
});
Clazz.overrideMethod (c$, "processBinaryDocument", 
function (doc) {
this.doResize = this.checkFilterKey ("DORESIZE");
this.allowSurface = !this.checkFilterKey ("NOSURFACE");
this.doCache = this.checkFilterKey ("DOCACHE");
if (this.doCache) this.bsExcluded =  new J.util.BS ();
var reader =  new J.adapter.readers.pymol.PickleReader (doc, this.viewer);
this.logging = false;
var map = reader.getMap (this.logging);
reader = null;
this.process (map);
}, "J.api.JmolDocument");
$_M(c$, "model", 
function (modelNumber) {
this.bsModelAtoms.clearAll ();
Clazz.superCall (this, J.adapter.readers.pymol.PyMOLReader, "model", [modelNumber]);
}, "~N");
Clazz.overrideMethod (c$, "setAdditionalAtomParameters", 
function (atom) {
}, "J.adapter.smarter.Atom");
Clazz.overrideMethod (c$, "finalizeModelSet", 
function (modelSet, baseModelIndex, baseAtomIndex) {
this.bsCarb = (this.haveTraceOrBackbone ? modelSet.getAtomBits (3145764, null) : null);
if (this.jmolObjects != null) {
for (var i = 0; i < this.jmolObjects.size (); i++) {
try {
var obj = this.jmolObjects.get (i);
obj.offset (baseModelIndex, baseAtomIndex);
obj.finalizeObject (modelSet, this);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
System.out.println (e);
} else {
throw e;
}
}
}
if (this.haveMeasurements) {
this.appendLoadNote (this.viewer.getMeasurementInfoAsString ());
this.setLoadNote ();
}}this.viewer.setTrajectoryBs (J.util.BSUtil.newBitSet2 (baseModelIndex, modelSet.modelCount));
if (!this.isStateScript && this.frameObj != null) {
this.frameObj.finalizeObject (modelSet, this);
}if (this.bsExcluded != null) {
var nExcluded = this.bsExcluded.cardinality ();
var bytes0 = this.viewer.getFileAsBytes (this.filePath, null);
var bytes =  Clazz.newByteArray (bytes0.length - nExcluded, 0);
for (var i = this.bsExcluded.nextClearBit (0), n = bytes0.length, pt = 0; i < n; i = this.bsExcluded.nextClearBit (i + 1)) bytes[pt++] = bytes0[i];

bytes0 = null;
var fileName = this.filePath;
this.viewer.cacheFile (fileName, bytes);
}}, "J.modelset.ModelSet,~N,~N");
$_M(c$, "process", 
($fz = function (map) {
this.pymolVersion = (map.get ("version")).intValue ();
this.appendLoadNote ("PyMOL version: " + this.pymolVersion);
this.settings = J.adapter.readers.pymol.PyMOLReader.getMapList (map, "settings");
var file = J.adapter.readers.pymol.PyMOLReader.listAt (this.settings, 440);
if (file != null) J.util.Logger.info ("PyMOL session file: " + file.get (2));
this.setVersionSettings ();
this.atomSetCollection.setAtomSetCollectionAuxiliaryInfo ("settings", this.settings);
this.setUniqueSettings (J.adapter.readers.pymol.PyMOLReader.getMapList (map, "unique_settings"));
this.logging = (this.viewer.getLogFile ().length > 0);
var names = J.adapter.readers.pymol.PyMOLReader.getMapList (map, "names");
for (var e, $e = map.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var name = e.getKey ();
J.util.Logger.info (name);
if (name.equals ("names")) {
for (var i = 1; i < names.size (); i++) J.util.Logger.info ("  " + J.adapter.readers.pymol.PyMOLReader.stringAt (J.adapter.readers.pymol.PyMOLReader.listAt (names, i), 0));

}}
if (this.logging) {
if (this.logging) this.viewer.log ("$CLEAR$");
for (var e, $e = map.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var name = e.getKey ();
if (!"names".equals (name)) {
this.viewer.log ("\n===" + name + "===");
this.viewer.log (J.util.TextFormat.simpleReplace (e.getValue ().toString (), "[", "\n["));
}}
this.viewer.log ("\n===names===");
for (var i = 1; i < names.size (); i++) {
this.viewer.log ("");
var list = names.get (i);
this.viewer.log (" =" + list.get (0).toString () + "=");
try {
this.viewer.log (J.util.TextFormat.simpleReplace (list.toString (), "[", "\n["));
} catch (e) {
e.printStackTrace ();
}
}
}this.addColors (J.adapter.readers.pymol.PyMOLReader.getMapList (map, "colors"), this.booleanSetting (214));
this.allStates = this.booleanSetting (49);
this.pymolFrame = Clazz.floatToInt (this.floatSetting (194));
this.pymolState = Clazz.floatToInt (this.floatSetting (193));
this.frameObj = this.addJmolObject (4115, null, (this.allStates ? Integer.$valueOf (-1) : Integer.$valueOf (this.pymolState - 1)));
this.appendLoadNote ("frame=" + this.pymolFrame + " state=" + this.pymolState + " all_states=" + this.allStates);
this.getAtomAndStateCount (names);
if (!this.isStateScript && this.doResize) {
var width = 0;
var height = 0;
try {
width = J.adapter.readers.pymol.PyMOLReader.intAt (J.adapter.readers.pymol.PyMOLReader.getMapList (map, "main"), 0);
height = J.adapter.readers.pymol.PyMOLReader.intAt (J.adapter.readers.pymol.PyMOLReader.getMapList (map, "main"), 1);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
} else {
throw e;
}
}
var note;
if (width > 0 && height > 0) {
note = "PyMOL dimensions width=" + width + " height=" + height;
this.atomSetCollection.setAtomSetCollectionAuxiliaryInfo ("perferredWidthHeight", [width, height]);
this.viewer.resizeInnerPanel (width, height);
} else {
note = "PyMOL dimensions?";
}this.appendLoadNote (note);
}var mov;
if (!this.isStateScript && !this.allStates && (mov = J.adapter.readers.pymol.PyMOLReader.getMapList (map, "movie")) != null) {
var frameCount = J.adapter.readers.pymol.PyMOLReader.intAt (mov, 0);
if (frameCount > 0) this.processMovie (mov, frameCount);
}if (this.totalAtomCount == 0) this.atomSetCollection.newAtomSet ();
J.adapter.readers.pymol.PyMOLReader.pointAt (J.adapter.readers.pymol.PyMOLReader.listAt (this.settings, 471).get (2), 0, this.labelPosition0);
this.selections =  new J.util.JmolList ();
if (this.allStates && this.desiredModelNumber == -2147483648) {
} else if (this.isMovie) {
switch (this.desiredModelNumber) {
case -2147483648:
break;
default:
this.desiredModelNumber = this.frames[(this.desiredModelNumber > 0 && this.desiredModelNumber <= this.frames.length ? this.desiredModelNumber : this.pymolFrame) - 1];
this.frameObj = this.addJmolObject (4115, null, Integer.$valueOf (this.desiredModelNumber - 1));
break;
}
} else if (this.desiredModelNumber == 0) {
this.desiredModelNumber = this.pymolState;
} else {
}for (var j = 0; j < this.stateCount; j++) {
if (!this.doGetModel (++this.nModels, null)) continue;
this.model (this.nModels);
if (this.isTrajectory) {
this.trajectoryStep =  new Array (this.totalAtomCount);
this.trajectorySteps.addLast (this.trajectoryStep);
this.trajectoryPtr = 0;
}for (var i = 1; i < names.size (); i++) this.processBranch (J.adapter.readers.pymol.PyMOLReader.listAt (names, i), true, j);

}
for (var i = 1; i < names.size (); i++) this.processBranch (J.adapter.readers.pymol.PyMOLReader.listAt (names, i), false, 0);

this.branchNameID = null;
if (this.mapObjects != null && this.allowSurface) this.processMeshes ();
if (this.isTrajectory) {
this.appendLoadNote ("PyMOL trajectories read: " + this.trajectorySteps.size ());
this.atomSetCollection.finalizeTrajectoryAs (this.trajectorySteps, null);
}this.processDefinitions ();
this.processScenes (map);
if (!this.isStateScript) this.setRendering (J.adapter.readers.pymol.PyMOLReader.getMapList (map, "view"));
if (this.$atomCount == 0) this.atomSetCollection.setAtomSetCollectionAuxiliaryInfo ("dataOnly", Boolean.TRUE);
}, $fz.isPrivate = true, $fz), "java.util.Map");
$_M(c$, "setVersionSettings", 
($fz = function () {
if (this.pymolVersion < 100) {
this.addSetting (550, 2, Integer.$valueOf (0));
this.addSetting (529, 2, Integer.$valueOf (2));
this.addSetting (471, 4, [1, 1, 0]);
if (this.pymolVersion < 99) {
this.addSetting (448, 2, Integer.$valueOf (0));
this.addSetting (431, 2, Integer.$valueOf (0));
this.addSetting (361, 2, Integer.$valueOf (1));
}}}, $fz.isPrivate = true, $fz));
$_M(c$, "setUniqueSettings", 
($fz = function (list) {
this.uniqueSettings =  new java.util.Hashtable ();
if (list != null && list.size () != 0) {
for (var i = list.size (); --i >= 0; ) {
var atomSettings = list.get (i);
var id = J.adapter.readers.pymol.PyMOLReader.intAt (atomSettings, 0);
var mySettings = atomSettings.get (1);
for (var j = mySettings.size (); --j >= 0; ) {
var setting = mySettings.get (j);
var uid = id * 1000 + J.adapter.readers.pymol.PyMOLReader.intAt (setting, 0);
this.uniqueSettings.put (Integer.$valueOf (uid), setting);
J.util.Logger.info ("PyMOL unique setting " + id + " " + setting);
}
}
}}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "addSetting", 
($fz = function (key, type, val) {
var settingCount = this.settings.size ();
if (settingCount <= key) for (var i = key + 1; --i >= settingCount; ) this.settings.addLast (null);

if (type == 4) {
var d = val;
var list;
val = list =  new J.util.JmolList ();
for (var i = 0; i < 3; i++) list.addLast (Double.$valueOf (d[i]));

}var setting =  new J.util.JmolList ();
setting.addLast (Integer.$valueOf (key));
setting.addLast (Integer.$valueOf (type));
setting.addLast (val);
this.settings.set (key, setting);
}, $fz.isPrivate = true, $fz), "~N,~N,~O");
$_M(c$, "addColors", 
($fz = function (colors, isClamped) {
if (colors == null || colors.size () == 0) return;
for (var i = colors.size (); --i >= 0; ) {
var c = J.adapter.readers.pymol.PyMOLReader.listAt (colors, i);
J.adapter.readers.pymol.PyMOL.addColor (c.get (1), isClamped ? J.adapter.readers.pymol.PyMOLReader.colorSettingClamped (c) : J.adapter.readers.pymol.PyMOLReader.colorSetting (c));
}
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~B");
$_M(c$, "getAtomAndStateCount", 
($fz = function (names) {
var n = 0;
for (var i = 1; i < names.size (); i++) {
var branch = J.adapter.readers.pymol.PyMOLReader.listAt (names, i);
var type = J.adapter.readers.pymol.PyMOLReader.getBranchType (branch);
if (!this.checkBranch (branch)) continue;
if (type == 1) {
var deepBranch = J.adapter.readers.pymol.PyMOLReader.listAt (branch, 5);
var states = J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 4);
var ns = states.size ();
if (ns > this.stateCount) this.stateCount = ns;
var nAtoms = J.adapter.readers.pymol.PyMOLReader.getBranchAtoms (deepBranch).size ();
for (var j = 0; j < ns; j++) {
var state = J.adapter.readers.pymol.PyMOLReader.listAt (states, j);
var idxToAtm = J.adapter.readers.pymol.PyMOLReader.listAt (state, 3);
if (idxToAtm == null) {
this.isTrajectory = false;
} else {
var m = idxToAtm.size ();
n += m;
if (this.isTrajectory && m != nAtoms) this.isTrajectory = false;
}}
}}
this.totalAtomCount = n;
J.util.Logger.info ("PyMOL total atom count = " + this.totalAtomCount);
J.util.Logger.info ("PyMOL state count = " + this.stateCount);
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "checkBranch", 
($fz = function (branch) {
this.branchName = J.adapter.readers.pymol.PyMOLReader.stringAt (branch, 0);
this.isHidden = (J.adapter.readers.pymol.PyMOLReader.intAt (branch, 2) != 1);
return (this.branchName.indexOf ("_") != 0);
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processMovie", 
($fz = function (mov, frameCount) {
var movie =  new java.util.Hashtable ();
movie.put ("frameCount", Integer.$valueOf (frameCount));
movie.put ("currentFrame", Integer.$valueOf (this.pymolFrame - 1));
var haveCommands = false;
var haveViews = false;
var haveFrames = false;
var list = J.adapter.readers.pymol.PyMOLReader.listAt (mov, 4);
for (var i = list.size (); --i >= 0; ) if (J.adapter.readers.pymol.PyMOLReader.intAt (list, i) != 0) {
this.frames =  Clazz.newIntArray (list.size (), 0);
for (var j = this.frames.length; --j >= 0; ) this.frames[j] = J.adapter.readers.pymol.PyMOLReader.intAt (list, j) + 1;

movie.put ("frames", this.frames);
haveFrames = true;
break;
}
var cmds = J.adapter.readers.pymol.PyMOLReader.listAt (mov, 5);
var cmd;
for (var i = cmds.size (); --i >= 0; ) if ((cmd = J.adapter.readers.pymol.PyMOLReader.stringAt (cmds, i)) != null && cmd.length > 1) {
cmds = J.adapter.readers.pymol.PyMOLReader.fixMovieCommands (cmds);
if (cmds != null) {
movie.put ("commands", cmds);
haveCommands = true;
break;
}}
var views = J.adapter.readers.pymol.PyMOLReader.listAt (mov, 6);
var view;
for (var i = views.size (); --i >= 0; ) if ((view = J.adapter.readers.pymol.PyMOLReader.listAt (views, i)) != null && view.size () >= 12 && view.get (1) != null) {
haveViews = true;
views = J.adapter.readers.pymol.PyMOLReader.fixMovieViews (views);
if (views != null) {
movie.put ("views", views);
break;
}}
this.appendLoadNote ("PyMOL movie frameCount = " + frameCount);
if (haveFrames && !haveCommands && !haveViews) {
this.isMovie = true;
this.branchNameID = null;
this.frameObj = this.getJmolObject (1073742032, null, movie);
} else {
}}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N");
c$.fixMovieViews = $_M(c$, "fixMovieViews", 
($fz = function (views) {
return views;
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
c$.fixMovieCommands = $_M(c$, "fixMovieCommands", 
($fz = function (cmds) {
return cmds;
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processBranch", 
($fz = function (branch, moleculeOnly, iState) {
var type = J.adapter.readers.pymol.PyMOLReader.getBranchType (branch);
var startLen = branch.get (branch.size () - 1);
if ((type == 1) != moleculeOnly || !this.checkBranch (branch)) return;
J.util.Logger.info ("PyMOL model " + (this.nModels) + " Branch " + this.branchName + (this.isHidden ? " (hidden)" : " (visible)"));
var deepBranch = J.adapter.readers.pymol.PyMOLReader.listAt (branch, 5);
this.branchNameID = J.adapter.readers.pymol.PyMOLReader.fixName (this.branchName + (moleculeOnly ? "_" + (iState + 1) : ""));
this.branchIDs.put (this.branchName, this.branchNameID);
var msg = null;
var branchInfo = J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 0);
this.setLocalSettings (J.adapter.readers.pymol.PyMOLReader.listAt (branchInfo, 8));
var doGroups = !this.isStateScript;
var parentGroupName = (!doGroups || branch.size () < 8 ? null : J.adapter.readers.pymol.PyMOLReader.stringAt (branch, 6));
var bsAtoms = null;
var doExclude = (this.bsExcluded != null);
switch (type) {
default:
msg = "" + type;
break;
case -1:
this.selections.addLast (branch);
break;
case 1:
doExclude = false;
bsAtoms = this.processMolecule (deepBranch, iState);
break;
case 4:
doExclude = false;
this.processMeasure (deepBranch);
break;
case 3:
case 2:
this.processMap (deepBranch, type == 3);
break;
case 8:
this.processGadget (deepBranch);
break;
case 12:
if (doGroups) this.addGroup (branch, null, type);
break;
case 6:
msg = "CGO";
this.processCGO (deepBranch);
break;
case 11:
msg = "ALIGNEMENT";
break;
case 9:
msg = "CALCULATOR";
break;
case 5:
msg = "CALLBACK";
break;
case 10:
msg = "SLICE";
break;
case 7:
msg = "SURFACE";
break;
}
if (parentGroupName != null) {
var group = this.addGroup (branch, parentGroupName, type);
if (bsAtoms != null) this.addGroupAtoms (group, bsAtoms);
}if (doExclude) {
var i0 = J.adapter.readers.pymol.PyMOLReader.intAt (startLen, 0);
var len = J.adapter.readers.pymol.PyMOLReader.intAt (startLen, 1);
this.bsExcluded.setBits (i0, i0 + len);
J.util.Logger.info ("cached PSE file excludes PyMOL object type " + type + " name=" + this.branchName + " len=" + len);
}if (msg != null) J.util.Logger.error ("Unprocessed branch type " + msg + " " + this.branchName);
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~B,~N");
$_M(c$, "setLocalSettings", 
($fz = function (list) {
this.localSettings =  new java.util.Hashtable ();
if (list != null && list.size () != 0) {
System.out.println ("local settings: " + list.toString ());
for (var i = list.size (); --i >= 0; ) {
var setting = list.get (i);
this.localSettings.put (setting.get (0), setting);
}
}this.nonBondedSize = this.floatSetting (65);
this.sphereScale = this.floatSetting (155);
this.valence = this.booleanSetting (64);
this.cartoonTranslucency = this.floatSetting (279);
this.stickTranslucency = this.floatSetting (198);
this.sphereTranslucency = this.floatSetting (172);
this.cartoonLadderMode = this.booleanSetting (448);
this.cartoonRockets = this.booleanSetting (180);
this.surfaceMode = Clazz.floatToInt (this.floatSetting (143));
this.surfaceColor = Clazz.floatToInt (this.floatSetting (144));
this.bgRgb = J.adapter.readers.pymol.PyMOLReader.colorSetting (J.adapter.readers.pymol.PyMOLReader.listAt (this.settings, 6));
this.labelPosition =  new J.util.P3 ();
try {
var setting = this.localSettings.get (Integer.$valueOf (471));
J.adapter.readers.pymol.PyMOLReader.pointAt (setting.get (2), 0, this.labelPosition);
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
} else {
throw e;
}
}
this.labelPosition.add (this.labelPosition0);
this.labelColor = this.floatSetting (66);
this.labelSize = this.floatSetting (453);
this.labelFontId = Clazz.floatToInt (this.floatSetting (328));
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "addGroup", 
($fz = function (branch, parent, type) {
if (this.groups == null) this.groups =  new java.util.Hashtable ();
var myGroup = this.getGroup (J.adapter.readers.pymol.PyMOLReader.fixName (this.branchName));
myGroup.branch = branch;
myGroup.branchNameID = this.branchNameID;
myGroup.visible = !this.isHidden;
myGroup.type = type;
if (parent != null) this.getGroup (J.adapter.readers.pymol.PyMOLReader.fixName (parent)).addList (myGroup);
return myGroup;
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~S,~N");
$_M(c$, "getGroup", 
($fz = function (name) {
var g = this.groups.get (name);
if (g == null) this.groups.put (name, (g =  new J.adapter.readers.pymol.PyMOLGroup (name)));
return g;
}, $fz.isPrivate = true, $fz), "~S");
$_M(c$, "addGroupAtoms", 
($fz = function (group, bsAtoms) {
group.bsAtoms = bsAtoms;
}, $fz.isPrivate = true, $fz), "J.adapter.readers.pymol.PyMOLGroup,J.util.BS");
$_M(c$, "processCGO", 
($fz = function (deepBranch) {
if (this.isStateScript) return;
if (this.isHidden) return;
var color = J.adapter.readers.pymol.PyMOLReader.intAt (J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 0), 2);
var data = J.adapter.readers.pymol.PyMOLReader.listAt (J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 2), 0);
data.addLast (this.branchName);
var jo = this.addJmolObject (23, null, data);
jo.argb = J.adapter.readers.pymol.PyMOL.getRGB (color);
jo.translucency = this.floatSetting (441);
this.appendLoadNote ("CGO " + J.adapter.readers.pymol.PyMOLReader.fixName (this.branchName));
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processGadget", 
($fz = function (deepBranch) {
if (this.branchName.endsWith ("_e_pot")) this.processMap (deepBranch, true);
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processMap", 
($fz = function (deepBranch, isObject) {
if (isObject) {
if (this.isStateScript) return;
if (this.isHidden) return;
if (this.mapObjects == null) this.mapObjects =  new J.util.JmolList ();
this.mapObjects.addLast (deepBranch);
} else {
if (this.volumeData == null) this.volumeData =  new java.util.Hashtable ();
this.volumeData.put (this.branchName, deepBranch);
if (!this.isHidden && !this.isStateScript) this.addJmolObject (135180, null, this.branchName);
}deepBranch.addLast (this.branchName);
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~B");
$_M(c$, "processMeasure", 
($fz = function (deepBranch) {
if (this.isStateScript) return;
if (this.isHidden) return;
J.util.Logger.info ("PyMOL measure " + this.branchName);
var measure = J.adapter.readers.pymol.PyMOLReader.listAt (J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 2), 0);
var set0 = J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 0);
var bsReps = J.adapter.readers.pymol.PyMOLReader.getBsReps (J.adapter.readers.pymol.PyMOLReader.listAt (set0, 3));
var drawLabel = bsReps.get (3) && measure.size () > 8;
var drawDashes = bsReps.get (10);
var pt;
var nCoord = (Clazz.instanceOf (measure.get (pt = 1), J.util.JmolList) ? 2 : Clazz.instanceOf (measure.get (pt = 4), J.util.JmolList) ? 3 : Clazz.instanceOf (measure.get (pt = 6), J.util.JmolList) ? 4 : 0);
if (nCoord == 0) return;
var list = J.adapter.readers.pymol.PyMOLReader.listAt (measure, pt);
var offsets = J.adapter.readers.pymol.PyMOLReader.listAt (measure, 8);
var len = list.size ();
var rad = this.floatSetting (107) / 20;
if (rad == 0) rad = 0.05;
if (!drawDashes) rad = -5.0E-4;
var index = 0;
var color = J.adapter.readers.pymol.PyMOLReader.intAt (set0, 2);
if (color < 0) color = Clazz.floatToInt (this.floatSetting (574));
var c = J.adapter.readers.pymol.PyMOL.getRGB (color);
var colix = J.util.C.getColix (c);
var clabel = Clazz.floatToInt (this.floatSetting (66));
if (clabel < 0) clabel = color;
for (var p = 0; p < len; ) {
var points =  new J.util.JmolList ();
for (var i = 0; i < nCoord; i++, p += 3) points.addLast (J.adapter.readers.pymol.PyMOLReader.pointAt (list, p,  new J.util.Point3fi ()));

var bs = J.util.BSUtil.newAndSetBit (0);
var offset = J.adapter.readers.pymol.PyMOLReader.floatsAt (J.adapter.readers.pymol.PyMOLReader.listAt (offsets, index++), 0,  Clazz.newFloatArray (7, 0), 7);
if (offset == null) offset = J.adapter.readers.pymol.PyMOLReader.setLabelPosition (this.labelPosition,  Clazz.newFloatArray (7, 0));
var md =  new J.modelset.MeasurementData (J.adapter.readers.pymol.PyMOLReader.fixName (this.branchNameID + "_" + index), this.viewer, points);
md.note = this.branchName;
var nDigits = Clazz.floatToInt (this.floatSetting (J.adapter.readers.pymol.PyMOLReader.MEAS_DIGITS[nCoord - 2]));
var strFormat = nCoord + ": " + (drawLabel ? "%0." + (nDigits < 0 ? 1 : nDigits) + "VALUE" : "");
var text = this.newTextLabel (strFormat, offset, clabel, Clazz.floatToInt (this.floatSetting (328)), this.floatSetting (453));
md.set (1060866, null, strFormat, "angstroms", null, false, false, null, false, Clazz.floatToInt (rad * 2000), colix, text);
this.addJmolObject (6, bs, md);
this.haveMeasurements = true;
}
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processMolecule", 
($fz = function (deepBranch, iState) {
this.$atomCount = this.atomCount0 = this.atomSetCollection.getAtomCount ();
var nAtoms = J.adapter.readers.pymol.PyMOLReader.intAt (deepBranch, 3);
if (nAtoms == 0) return null;
this.ssMapSeq =  new java.util.Hashtable ();
this.ssMapAtom =  new java.util.Hashtable ();
this.labels =  new J.util.JmolList ();
this.atomMap =  Clazz.newIntArray (nAtoms, 0);
if (iState == 0) this.processMolCryst (J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 10));
var bonds = this.processMolBonds (J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 6));
var states = J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 4);
this.pymolAtoms = J.adapter.readers.pymol.PyMOLReader.getBranchAtoms (deepBranch);
var fname = "__" + J.adapter.readers.pymol.PyMOLReader.fixName (this.branchName);
var bsAtoms = this.htNames.get (fname);
if (bsAtoms == null) {
bsAtoms = J.util.BS.newN (this.atomCount0 + nAtoms);
J.util.Logger.info ("PyMOL molecule " + this.branchName);
this.htNames.put (fname, bsAtoms);
}for (var i = 0; i < 15; i++) this.reps[i] = J.util.BS.newN (1000);

var state = J.adapter.readers.pymol.PyMOLReader.listAt (states, iState);
var idxToAtm = J.adapter.readers.pymol.PyMOLReader.listAt (state, 3);
var n = (idxToAtm == null ? 0 : idxToAtm.size ());
if (n == 0) return null;
var coords = J.adapter.readers.pymol.PyMOLReader.listAt (state, 2);
var labelPositions = J.adapter.readers.pymol.PyMOLReader.listAt (state, 8);
if (iState == 0 || !this.isTrajectory) for (var idx = 0; idx < n; idx++) {
var a = this.addAtom (this.pymolAtoms, J.adapter.readers.pymol.PyMOLReader.intAt (idxToAtm, idx), idx, coords, labelPositions, bsAtoms, iState);
if (a != null) this.trajectoryStep[this.trajectoryPtr++] = a;
}
this.addBonds (bonds);
this.addMolStructures ();
if (!this.isStateScript) this.createShapeObjects ();
this.ssMapSeq = this.ssMapAtom = null;
J.util.Logger.info ("reading " + (this.$atomCount - this.atomCount0) + " atoms");
J.util.Logger.info ("----------");
return bsAtoms;
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N");
$_M(c$, "processMolCryst", 
($fz = function (cryst) {
if (cryst == null || cryst.size () == 0) return;
var l = J.adapter.readers.pymol.PyMOLReader.listAt (J.adapter.readers.pymol.PyMOLReader.listAt (cryst, 0), 0);
var a = J.adapter.readers.pymol.PyMOLReader.listAt (J.adapter.readers.pymol.PyMOLReader.listAt (cryst, 0), 1);
this.setUnitCell (J.adapter.readers.pymol.PyMOLReader.floatAt (l, 0), J.adapter.readers.pymol.PyMOLReader.floatAt (l, 1), J.adapter.readers.pymol.PyMOLReader.floatAt (l, 2), J.adapter.readers.pymol.PyMOLReader.floatAt (a, 0), J.adapter.readers.pymol.PyMOLReader.floatAt (a, 1), J.adapter.readers.pymol.PyMOLReader.floatAt (a, 2));
this.setSpaceGroupName (J.adapter.readers.pymol.PyMOLReader.stringAt (cryst, 1));
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "processMolBonds", 
($fz = function (bonds) {
var bondList =  new J.util.JmolList ();
var color = Clazz.floatToInt (this.floatSetting (376));
var radius = this.floatSetting (21) / 2;
var translucency = this.floatSetting (198);
var n = bonds.size ();
for (var i = 0; i < n; i++) {
var b = J.adapter.readers.pymol.PyMOLReader.listAt (bonds, i);
var order = (this.valence ? J.adapter.readers.pymol.PyMOLReader.intAt (b, 2) : 1);
if (order < 1 || order > 3) order = 1;
var ia = J.adapter.readers.pymol.PyMOLReader.intAt (b, 0);
var ib = J.adapter.readers.pymol.PyMOLReader.intAt (b, 1);
var bond =  new J.adapter.smarter.Bond (ia, ib, order);
bondList.addLast (bond);
var c;
var rad;
var t;
var hasID = (b.size () > 6 && J.adapter.readers.pymol.PyMOLReader.intAt (b, 6) != 0);
if (hasID) {
var id = J.adapter.readers.pymol.PyMOLReader.intAt (b, 5);
rad = this.getUniqueFloat (id, 21, radius) / 2;
c = Clazz.floatToInt (this.getUniqueFloat (id, 376, color));
t = this.getUniqueFloat (id, 198, translucency);
} else {
rad = radius;
c = color;
t = translucency;
}bond.radius = rad;
if (c >= 0) bond.colix = J.util.C.getColixTranslucent3 (J.util.C.getColix (J.adapter.readers.pymol.PyMOL.getRGB (c)), t > 0, t);
}
return bondList;
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "addAtom", 
($fz = function (pymolAtoms, apt, icoord, coords, labelPositions, bsState, iState) {
this.atomMap[apt] = -1;
var a = J.adapter.readers.pymol.PyMOLReader.listAt (pymolAtoms, apt);
var seqNo = J.adapter.readers.pymol.PyMOLReader.intAt (a, 0);
var chainID = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 1);
var altLoc = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 2);
var insCode = " ";
var name = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 6);
var group3 = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 5);
if (group3.length > 3) group3 = group3.substring (0, 3);
if (group3.equals (" ")) group3 = "UNK";
var sym = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 7);
if (sym.equals ("A")) sym = "C";
var isHetero = (J.adapter.readers.pymol.PyMOLReader.intAt (a, 19) != 0);
var atom = this.processAtom ( new J.adapter.readers.pymol.PyMOLAtom (), name, altLoc.charAt (0), group3, chainID.charAt (0), seqNo, insCode.charAt (0), isHetero, sym);
if (!this.filterPDBAtom (atom, this.fileAtomIndex++)) return null;
icoord *= 3;
var x = J.adapter.readers.pymol.PyMOLReader.floatAt (coords, icoord);
var y = J.adapter.readers.pymol.PyMOLReader.floatAt (coords, ++icoord);
var z = J.adapter.readers.pymol.PyMOLReader.floatAt (coords, ++icoord);
J.util.BoxInfo.addPointXYZ (x, y, z, this.xyzMin, this.xyzMax, 0);
if (this.isTrajectory && iState > 0) return null;
this.bsHidden.setBitTo (this.$atomCount, this.isHidden);
this.bsModelAtoms.set (this.$atomCount);
if (bsState != null) bsState.set (this.$atomCount);
var isNucleic = (J.adapter.readers.pymol.PyMOLReader.nucleic.indexOf (group3) >= 0);
if (isNucleic) this.bsNucleic.set (this.$atomCount);
atom.label = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 9);
var ssType = J.adapter.readers.pymol.PyMOLReader.stringAt (a, 10);
if (seqNo >= -1000 && (!ssType.equals (" ") || name.equals ("CA") || isNucleic)) {
if (this.ssMapAtom.get (ssType) == null) this.ssMapAtom.put (ssType,  new J.util.BS ());
var bs = this.ssMapSeq.get (ssType);
if (bs == null) this.ssMapSeq.put (ssType, bs =  new J.util.BS ());
bs.set (seqNo - -1000);
ssType += chainID;
bs = this.ssMapSeq.get (ssType);
if (bs == null) this.ssMapSeq.put (ssType, bs =  new J.util.BS ());
bs.set (seqNo - -1000);
}atom.bfactor = J.adapter.readers.pymol.PyMOLReader.floatAt (a, 14);
atom.occupancy = Clazz.floatToInt (J.adapter.readers.pymol.PyMOLReader.floatAt (a, 15) * 100);
atom.radius = J.adapter.readers.pymol.PyMOLReader.floatAt (a, 16);
if (atom.radius == 0) atom.radius = 1;
atom.partialCharge = J.adapter.readers.pymol.PyMOLReader.floatAt (a, 17);
var formalCharge = J.adapter.readers.pymol.PyMOLReader.intAt (a, 18);
atom.bsReps = J.adapter.readers.pymol.PyMOLReader.getBsReps (J.adapter.readers.pymol.PyMOLReader.listAt (a, 20));
var translucency = this.getUniqueFloat (atom.uniqueID, 172, this.sphereTranslucency);
var atomColor = J.adapter.readers.pymol.PyMOLReader.intAt (a, 21);
this.atomColorList.addLast (Integer.$valueOf (this.getColix (atomColor, translucency)));
var serNo = J.adapter.readers.pymol.PyMOLReader.intAt (a, 22);
atom.cartoonType = J.adapter.readers.pymol.PyMOLReader.intAt (a, 23);
atom.flags = J.adapter.readers.pymol.PyMOLReader.intAt (a, 24);
atom.bonded = J.adapter.readers.pymol.PyMOLReader.intAt (a, 25) != 0;
if (a.size () > 40 && J.adapter.readers.pymol.PyMOLReader.intAt (a, 40) == 1) atom.uniqueID = J.adapter.readers.pymol.PyMOLReader.intAt (a, 32);
if (a.size () > 46) {
var data = J.adapter.readers.pymol.PyMOLReader.floatsAt (a, 41,  Clazz.newFloatArray (7, 0), 6);
this.atomSetCollection.setAnisoBorU (atom, data, 12);
}this.processAtom2 (atom, serNo, x, y, z, formalCharge);
this.setAtomReps (atom, apt, atomColor, labelPositions);
this.atomMap[apt] = this.$atomCount++;
return null;
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N,~N,J.util.JmolList,J.util.JmolList,J.util.BS,~N");
$_M(c$, "setAtomReps", 
($fz = function (atom, apt, atomColor, labelPositions) {
var iAtom = atom.atomIndex;
if (atom.bsReps.get (11) && atom.bonded) atom.bsReps.clear (11);
if (atom.bsReps.get (3) && atom.label.equals (" ")) atom.bsReps.clear (3);
var isVisible = !atom.bsReps.isEmpty ();
var isH = atom.elementSymbol.equals ("H");
var surfaceAtom = (this.allowSurface && !this.isHidden);
if (surfaceAtom) switch (this.surfaceMode) {
case 0:
surfaceAtom = ((atom.flags & J.adapter.readers.pymol.PyMOL.FLAG_NOSURFACE) == 0);
break;
case 1:
surfaceAtom = true;
break;
case 2:
surfaceAtom = !isH;
break;
case 3:
surfaceAtom = isVisible;
break;
case 4:
surfaceAtom = isVisible && !isH;
break;
}
if (!surfaceAtom) {
atom.bsReps.clear (8);
atom.bsReps.clear (2);
}for (var i = 0; i < 12; i++) if (atom.bsReps.get (i)) this.reps[i].set (iAtom);

if (this.reps[3].get (iAtom)) {
var icolor = Clazz.floatToInt (this.getUniqueFloat (atom.uniqueID, 66, this.labelColor));
if (icolor == -7 || icolor == -6) {
} else if (icolor < 0) {
icolor = atomColor;
}var labelPos =  Clazz.newFloatArray (7, 0);
var labelOffset = J.adapter.readers.pymol.PyMOLReader.listAt (labelPositions, apt);
if (labelOffset == null) {
var offset = this.getUniquePoint (atom.uniqueID, 471, null);
if (offset == null) offset = this.labelPosition;
 else offset.add (this.labelPosition);
J.adapter.readers.pymol.PyMOLReader.setLabelPosition (offset, labelPos);
} else {
for (var i = 0; i < 7; i++) labelPos[i] = J.adapter.readers.pymol.PyMOLReader.floatAt (labelOffset, i);

}this.labels.addLast (this.newTextLabel (atom.label, labelPos, icolor, Clazz.floatToInt (this.getUniqueFloat (atom.uniqueID, 328, this.labelFontId)), this.getUniqueFloat (atom.uniqueID, 453, this.labelSize)));
}var rad = 0;
if (this.reps[1].get (iAtom)) {
rad = atom.radius * this.getUniqueFloat (atom.uniqueID, 155, this.sphereScale);
} else if (this.reps[4].get (iAtom)) {
rad = this.getUniqueFloat (atom.uniqueID, 65, this.nonBondedSize);
}if (rad != 0) {
var r = Float.$valueOf (rad);
var bsr = this.htSpacefill.get (r);
if (bsr == null) this.htSpacefill.put (r, bsr =  new J.util.BS ());
bsr.set (iAtom);
}if (this.reps[5].get (iAtom)) {
switch (atom.cartoonType) {
case 1:
case 4:
this.reps[13].set (iAtom);
case -1:
this.reps[5].clear (iAtom);
break;
case 7:
this.reps[5].clear (iAtom);
this.reps[14].set (iAtom);
break;
}
}}, $fz.isPrivate = true, $fz), "J.adapter.readers.pymol.PyMOLAtom,~N,~N,J.util.JmolList");
c$.setLabelPosition = $_M(c$, "setLabelPosition", 
($fz = function (offset, labelPos) {
labelPos[0] = 1;
labelPos[1] = offset.x;
labelPos[2] = offset.y;
labelPos[3] = offset.z;
return labelPos;
}, $fz.isPrivate = true, $fz), "J.util.P3,~A");
$_M(c$, "newTextLabel", 
($fz = function (label, labelOffset, colorIndex, fontID, fontSize) {
var face;
var factor = 1;
switch (fontID) {
default:
case 11:
case 12:
case 13:
case 14:
face = "SansSerif";
break;
case 0:
case 1:
face = "Monospaced";
break;
case 9:
case 10:
case 15:
case 16:
case 17:
case 18:
face = "Serif";
break;
}
var style;
switch (fontID) {
default:
style = "Plain";
break;
case 6:
case 12:
case 16:
case 17:
style = "Italic";
break;
case 7:
case 10:
case 13:
style = "Bold";
break;
case 8:
case 14:
case 18:
style = "BoldItalic";
break;
}
var font = this.viewer.getFont3D (face, style, fontSize == 0 ? 12 : fontSize * factor);
var t = J.modelset.Text.newLabel (this.viewer.getGraphicsData (), font, label, this.getColix (colorIndex, 0), 0, 0, 0, labelOffset);
return t;
}, $fz.isPrivate = true, $fz), "~S,~A,~N,~N,~N");
$_M(c$, "addBonds", 
($fz = function (bonds) {
var n = bonds.size ();
for (var i = 0; i < n; i++) {
var bond = bonds.get (i);
bond.atomIndex1 = this.atomMap[bond.atomIndex1];
bond.atomIndex2 = this.atomMap[bond.atomIndex2];
if (bond.atomIndex1 >= 0 && bond.atomIndex2 >= 0) this.atomSetCollection.addBond (bond);
}
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "addMolStructures", 
($fz = function () {
if (this.atomSetCollection.bsStructuredModels == null) this.atomSetCollection.bsStructuredModels =  new J.util.BS ();
this.atomSetCollection.bsStructuredModels.set (Math.max (this.atomSetCollection.getCurrentAtomSetIndex (), 0));
this.addMolSS ("H", this.ssMapAtom.get ("H"), J.constant.EnumStructure.HELIX);
this.addMolSS ("S", this.ssMapAtom.get ("S"), J.constant.EnumStructure.SHEET);
this.addMolSS ("L", this.ssMapAtom.get ("L"), J.constant.EnumStructure.TURN);
this.addMolSS (" ", this.ssMapAtom.get (" "), J.constant.EnumStructure.NONE);
}, $fz.isPrivate = true, $fz));
$_M(c$, "addMolSS", 
($fz = function (ssType, bsAtom, type) {
if (this.ssMapSeq.get (ssType) == null) return;
var istart = -1;
var iend = -1;
var ichain = '\u0000';
var atoms = this.atomSetCollection.getAtoms ();
var bsSeq = null;
var n = this.$atomCount + 1;
var seqNo = -1;
var thischain = '\u0000';
var imodel = -1;
var thismodel = -1;
for (var i = this.atomCount0; i < n; i++) {
if (i == this.$atomCount) {
thischain = '\0';
} else {
seqNo = atoms[i].sequenceNumber;
thischain = atoms[i].chainID;
thismodel = atoms[i].atomSetIndex;
}if (thischain != ichain || thismodel != imodel) {
ichain = thischain;
imodel = thismodel;
bsSeq = this.ssMapSeq.get (ssType + thischain);
--i;
if (istart < 0) continue;
} else if (bsSeq != null && seqNo >= -1000 && bsSeq.get (seqNo - -1000)) {
iend = i;
if (istart < 0) istart = i;
continue;
} else if (istart < 0) {
continue;
}if (type !== J.constant.EnumStructure.NONE) {
var pt = this.bsStructureDefined.nextSetBit (istart);
if (pt >= 0 && pt <= iend) continue;
this.bsStructureDefined.setBits (istart, iend + 1);
var structure =  new J.adapter.smarter.Structure (imodel, type, type, type.toString (), ++this.structureCount, type === J.constant.EnumStructure.SHEET ? 1 : 0);
var a = atoms[istart];
var b = atoms[iend];
structure.set (a.chainID, a.sequenceNumber, a.insertionCode, b.chainID, b.sequenceNumber, b.insertionCode, istart, iend);
this.atomSetCollection.addStructure (structure);
}bsAtom.setBits (istart, iend + 1);
istart = -1;
}
}, $fz.isPrivate = true, $fz), "~S,J.util.BS,J.constant.EnumStructure");
$_M(c$, "createShapeObjects", 
($fz = function () {
var bs = J.util.BSUtil.newBitSet2 (this.atomCount0, this.$atomCount);
var jo = this.addJmolObject (0, bs, null);
this.colixes = J.util.ArrayUtil.ensureLengthShort (this.colixes, this.$atomCount);
for (var i = this.$atomCount; --i >= this.atomCount0; ) this.colixes[i] = this.atomColorList.get (i).intValue ();

jo.setColors (this.colixes, 0);
jo.setSize (0);
jo = this.addJmolObject (1, bs, null);
jo.setSize (0);
this.createSpacefillObject ();
var atoms = this.atomSetCollection.getAtoms ();
J.adapter.readers.pymol.PyMOLReader.cleanSingletons (atoms, this.reps[5]);
J.adapter.readers.pymol.PyMOLReader.cleanSingletons (atoms, this.reps[13]);
J.adapter.readers.pymol.PyMOLReader.cleanSingletons (atoms, this.reps[14]);
this.createShapeObject (7);
this.createShapeObject (0);
for (var i = 0; i < 15; i++) switch (i) {
case 7:
case 0:
continue;
default:
this.createShapeObject (i);
continue;
}

}, $fz.isPrivate = true, $fz));
$_M(c$, "createSpacefillObject", 
($fz = function () {
for (var e, $e = this.htSpacefill.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var r = e.getKey ().floatValue ();
var bs = e.getValue ();
System.out.println (r + " sf " + J.util.Escape.eBS (bs));
this.addJmolObject (0, bs, null).rd =  new J.atomdata.RadiusData (null, r, J.atomdata.RadiusData.EnumType.ABSOLUTE, J.constant.EnumVdw.AUTO);
}
this.htSpacefill.clear ();
}, $fz.isPrivate = true, $fz));
c$.cleanSingletons = $_M(c$, "cleanSingletons", 
($fz = function (atoms, bs) {
var bsr =  new J.util.BS ();
var n = bs.length ();
var pass = 0;
while (true) {
for (var i = 0, offset = 0, iPrev = -2147483648, iSeqLast = -2147483648, iSeq = -2147483648; i < n; i++) {
if (iPrev < 0 || atoms[iPrev].chainID != atoms[i].chainID) offset++;
iSeq = atoms[i].sequenceNumber;
if (iSeq != iSeqLast) {
iSeqLast = iSeq;
offset++;
}if (pass == 0) {
if (bs.get (i)) bsr.set (offset);
} else if (!bsr.get (offset)) bs.clear (i);
iPrev = i;
}
if (++pass == 2) break;
var bsnot =  new J.util.BS ();
for (var i = bsr.nextSetBit (0); i >= 0; i = bsr.nextSetBit (i + 1)) if (!bsr.get (i - 1) && !bsr.get (i + 1)) bsnot.set (i);

bsr.andNot (bsnot);
}
}, $fz.isPrivate = true, $fz), "~A,J.util.BS");
$_M(c$, "createShapeObject", 
($fz = function (shapeID) {
var bs = this.reps[shapeID];
var f;
if (bs.isEmpty ()) return;
var jo = null;
switch (shapeID) {
case 11:
jo = this.addJmolObject (7, bs, null);
jo.rd =  new J.atomdata.RadiusData (null, this.floatSetting (65) / 2, J.atomdata.RadiusData.EnumType.FACTOR, J.constant.EnumVdw.AUTO);
break;
case 4:
case 1:
jo = this.addJmolObject (0, bs, null);
jo.translucency = this.sphereTranslucency;
break;
case 9:
jo = this.addJmolObject (16, bs, null);
f = this.floatSetting (155);
jo.rd =  new J.atomdata.RadiusData (null, f, J.atomdata.RadiusData.EnumType.FACTOR, J.constant.EnumVdw.AUTO);
break;
case 5:
this.createCartoonObject ("H", (this.cartoonRockets ? 181 : 100));
this.createCartoonObject ("S", 96);
this.createCartoonObject ("L", 92);
this.createCartoonObject (" ", 92);
break;
case 8:
jo = this.addJmolObject (135180, bs, null);
jo.setSize (this.floatSetting (4));
jo.translucency = this.floatSetting (138);
break;
case 2:
this.surfaceCount++;
jo = this.addJmolObject (135180, bs, this.booleanSetting (156) ? "FULLYLIT" : "FRONTLIT");
jo.setSize (this.floatSetting (4));
jo.translucency = this.floatSetting (138);
if (this.surfaceColor >= 0) jo.argb = J.adapter.readers.pymol.PyMOL.getRGB (this.surfaceColor);
break;
case 3:
jo = this.addJmolObject (5, bs, this.labels);
break;
case 14:
this.createPuttyObject (bs);
break;
case 13:
this.haveTraceOrBackbone = true;
this.createTraceObject (bs);
break;
case 6:
this.haveTraceOrBackbone = true;
this.createRibbonObject (bs);
break;
case 7:
jo = this.addJmolObject (1, bs, null);
jo.setSize (this.floatSetting (44) / 15);
break;
case 0:
jo = this.addJmolObject (1, bs, null);
jo.setSize (this.floatSetting (21) * 2);
jo.translucency = this.stickTranslucency;
break;
case 10:
default:
J.util.Logger.error ("Unprocessed representation type " + shapeID);
}
}, $fz.isPrivate = true, $fz), "~N");
$_M(c$, "createTraceObject", 
($fz = function (bs) {
var jo;
var bsNuc = J.util.BSUtil.copy (this.bsNucleic);
bsNuc.and (bs);
if (this.cartoonLadderMode && !bsNuc.isEmpty ()) {
this.haveNucleicLadder = true;
jo = this.addJmolObject (11, bsNuc, null);
jo.translucency = this.cartoonTranslucency;
jo.setSize (this.floatSetting (103) * 2);
bs.andNot (bsNuc);
if (bs.isEmpty ()) return;
}jo = this.addJmolObject (10, bs, null);
jo.translucency = this.cartoonTranslucency;
jo.setSize (this.floatSetting (103) * 2);
}, $fz.isPrivate = true, $fz), "J.util.BS");
$_M(c$, "createPuttyObject", 
($fz = function (bs) {
var info = [this.floatSetting (378), this.floatSetting (377), this.floatSetting (382), this.floatSetting (379), this.floatSetting (380), this.floatSetting (381), this.floatSetting (581)];
this.addJmolObject (10, bs, info).translucency = this.cartoonTranslucency;
}, $fz.isPrivate = true, $fz), "J.util.BS");
$_M(c$, "createRibbonObject", 
($fz = function (bs) {
var sampling = this.floatSetting (19);
var isTrace = (sampling > 1);
var r = this.floatSetting (20) * 2;
var rpc = this.floatSetting (327);
if (r == 0) r = this.floatSetting (106) * (isTrace ? 0.1 : (rpc < 1 ? 1 : rpc) * 0.05);
this.addJmolObject ((isTrace ? 10 : 9), bs, null).setSize (r);
}, $fz.isPrivate = true, $fz), "J.util.BS");
$_M(c$, "createCartoonObject", 
($fz = function (key, sizeID) {
var bs = J.util.BSUtil.copy (this.ssMapAtom.get (key));
if (bs == null) return;
bs.and (this.reps[5]);
if (bs.isEmpty ()) return;
var jo = this.addJmolObject (11, bs, null);
jo.translucency = this.cartoonTranslucency;
jo.setSize (this.floatSetting (sizeID) * 2);
}, $fz.isPrivate = true, $fz), "~S,~N");
$_M(c$, "processMeshes", 
($fz = function () {
this.viewer.cachePut (this.filePath + "#jmolSurfaceInfo", this.volumeData);
for (var i = this.mapObjects.size (); --i >= 0; ) {
var obj = this.mapObjects.get (i);
var objName = obj.get (obj.size () - 1).toString ();
var isMep = objName.endsWith ("_e_pot");
var mapName;
var tok;
if (isMep) {
tok = 1073742016;
var root = objName.substring (0, objName.length - 3);
mapName = root + "map";
var isosurfaceName = this.branchIDs.get (root + "chg");
if (isosurfaceName == null) continue;
obj.addLast (isosurfaceName);
this.mepList += ";" + isosurfaceName + ";";
} else {
tok = 1073742018;
mapName = J.adapter.readers.pymol.PyMOLReader.stringAt (J.adapter.readers.pymol.PyMOLReader.listAt (J.adapter.readers.pymol.PyMOLReader.listAt (obj, 2), 0), 1);
}var surface = this.volumeData.get (mapName);
if (surface == null) continue;
obj.addLast (mapName);
this.appendLoadNote ("PyMOL object " + objName + " references map " + mapName);
this.volumeData.put (objName, obj);
this.volumeData.put ("__pymolSurfaceData__", obj);
if (!this.isStateScript) {
var jo = this.addJmolObject (tok, null, obj);
if (isMep) {
} else {
jo.setSize (this.floatSetting (90));
jo.argb = J.adapter.readers.pymol.PyMOL.getRGB (J.adapter.readers.pymol.PyMOLReader.intAt (J.adapter.readers.pymol.PyMOLReader.listAt (obj, 0), 2));
}jo.translucency = this.floatSetting (138);
}}
}, $fz.isPrivate = true, $fz));
$_M(c$, "processDefinitions", 
($fz = function () {
this.addJmolObject (1060866, null, this.htNames);
var s = this.viewer.getAtomDefs (this.htNames);
if (s.length > 2) s = s.substring (0, s.length - 2);
this.appendLoadNote (s);
}, $fz.isPrivate = true, $fz));
$_M(c$, "processScenes", 
($fz = function (map) {
var order = J.adapter.readers.pymol.PyMOLReader.getMapList (map, "scene_order");
if (order == null || order.size () == 0) return;
var scenes = map.get ("scene_dict");
for (var i = 0; i < order.size (); i++) {
var name = J.adapter.readers.pymol.PyMOLReader.stringAt (order, i);
var smap =  new java.util.Hashtable ();
var scene = J.adapter.readers.pymol.PyMOLReader.getMapList (scenes, name);
if (scene == null) continue;
var view = J.adapter.readers.pymol.PyMOLReader.listAt (scene, 0);
if (view == null) continue;
smap.put ("pymolView", this.getPymolView (view, false));
this.addJmolObject (1073742139, null, smap).branchNameID = name;
this.appendLoadNote ("scene: " + name);
}
}, $fz.isPrivate = true, $fz), "java.util.Map");
$_M(c$, "setRendering", 
($fz = function (view) {
this.viewer.initialize (true);
this.viewer.setStringProperty ("measurementUnits", "ANGSTROMS");
this.viewer.setBooleanProperty ("zoomHeight", true);
if (this.groups != null) this.setGroupVisibilities ();
if (!this.bsHidden.isEmpty ()) this.addJmolObject (3145770, this.bsHidden, null);
this.addJmolScript (this.getViewScript (view).toString ());
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "setGroupVisibilities", 
($fz = function () {
var list = this.groups.values ();
for (var g, $g = list.iterator (); $g.hasNext () && ((g = $g.next ()) || true);) {
if (g.parent != null) continue;
this.setGroupVisible (g, true);
}
this.addJmolObject (1087373318, null, this.groups);
for (var i = this.jmolObjects.size (); --i >= 0; ) {
var obj = this.jmolObjects.get (i);
if (obj.branchNameID != null && this.occludedBranches.containsKey (obj.branchNameID)) obj.visible = false;
}
}, $fz.isPrivate = true, $fz));
$_M(c$, "setGroupVisible", 
($fz = function (g, parentVis) {
var vis = parentVis && g.visible;
if (!vis) switch (g.type) {
case 1:
if (g.bsAtoms != null) this.bsHidden.or (g.bsAtoms);
break;
default:
g.occluded = true;
this.occludedBranches.put (g.branchNameID, Boolean.TRUE);
break;
}
for (var i = g.list.size (); --i >= 0; ) {
var gg = g.list.get (i);
this.setGroupVisible (gg, vis);
}
}, $fz.isPrivate = true, $fz), "J.adapter.readers.pymol.PyMOLGroup,~B");
$_M(c$, "getViewScript", 
($fz = function (view) {
var sb =  new J.util.SB ();
var pymolView = this.getPymolView (view, true);
sb.append (";set zshadePower 1;set traceAlpha " + this.booleanSetting (111));
sb.append (";set cartoonRockets " + this.cartoonRockets);
if (this.cartoonRockets) sb.append (";set rocketBarrels " + this.cartoonRockets);
sb.append (";set cartoonLadders " + this.haveNucleicLadder);
sb.append (";set ribbonBorder " + this.booleanSetting (118));
sb.append (";set cartoonFancy " + !this.booleanSetting (118));
var s = "000000" + Integer.toHexString (this.bgRgb);
s = "[x" + s.substring (s.length - 6) + "]";
sb.append (";background " + s);
sb.append (";moveto 0 PyMOL " + J.util.Escape.eAF (pymolView));
sb.append (";");
return sb;
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
$_M(c$, "getPymolView", 
($fz = function (view, isViewObj) {
var pymolView =  Clazz.newFloatArray (21, 0);
var depthCue = this.booleanSetting (84);
var fog = this.booleanSetting (88);
var fog_start = this.floatSetting (192);
var pt = 0;
var i = 0;
for (var j = 0; j < 3; j++) pymolView[pt++] = J.adapter.readers.pymol.PyMOLReader.floatAt (view, i++);

if (isViewObj) i++;
for (var j = 0; j < 3; j++) pymolView[pt++] = J.adapter.readers.pymol.PyMOLReader.floatAt (view, i++);

if (isViewObj) i++;
for (var j = 0; j < 3; j++) pymolView[pt++] = J.adapter.readers.pymol.PyMOLReader.floatAt (view, i++);

if (isViewObj) i += 5;
for (var j = 0; j < 8; j++) pymolView[pt++] = J.adapter.readers.pymol.PyMOLReader.floatAt (view, i++);

var isOrtho = this.booleanSetting (23);
var fov = this.floatSetting (152);
pymolView[pt++] = (isOrtho ? fov : -fov);
pymolView[pt++] = (depthCue ? 1 : 0);
pymolView[pt++] = (fog ? 1 : 0);
pymolView[pt++] = fog_start;
return pymolView;
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~B");
$_M(c$, "addJmolObject", 
($fz = function (id, bsAtoms, info) {
var obj = this.getJmolObject (id, bsAtoms, info);
this.jmolObjects.addLast (obj);
return obj;
}, $fz.isPrivate = true, $fz), "~N,J.util.BS,~O");
$_M(c$, "getJmolObject", 
($fz = function (id, bsAtoms, info) {
return  new J.adapter.readers.pymol.JmolObject (id, this.branchNameID, bsAtoms, info);
}, $fz.isPrivate = true, $fz), "~N,J.util.BS,~O");
$_M(c$, "haveMep", 
function (sID) {
return J.util.Parser.isOneOf (sID, this.mepList);
}, "~S");
$_M(c$, "booleanSetting", 
($fz = function (i) {
return (this.floatSetting (i) != 0);
}, $fz.isPrivate = true, $fz), "~N");
$_M(c$, "floatSetting", 
($fz = function (i) {
try {
var setting = null;
if (this.localSettings != null) setting = this.localSettings.get (Integer.$valueOf (i));
if (setting == null) setting = J.adapter.readers.pymol.PyMOLReader.listAt (this.settings, i);
return (setting.get (2)).floatValue ();
} catch (e) {
if (Clazz.exceptionOf (e, Exception)) {
return J.adapter.readers.pymol.PyMOL.getDefaultSetting (i, this.pymolVersion);
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "~N");
$_M(c$, "getUniqueFloat", 
($fz = function (id, key, defaultValue) {
var setting;
if (id < 0 || (setting = this.uniqueSettings.get (Integer.$valueOf (id * 1000 + key))) == null) return defaultValue;
var v = (setting.get (2)).floatValue ();
J.util.Logger.info ("Pymol unique setting for " + id + ": [" + key + "] = " + v);
return v;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
$_M(c$, "getUniquePoint", 
($fz = function (id, key, pt) {
var setting;
if (id < 0 || (setting = this.uniqueSettings.get (Integer.$valueOf (id * 1000 + key))) == null) return pt;
pt =  new J.util.P3 ();
J.adapter.readers.pymol.PyMOLReader.pointAt (setting.get (2), 0, pt);
J.util.Logger.info ("Pymol unique setting for " + id + ": " + key + " = " + pt);
return pt;
}, $fz.isPrivate = true, $fz), "~N,~N,J.util.P3");
$_M(c$, "getColix", 
($fz = function (colorIndex, translucency) {
var colix = (colorIndex == -7 ? (J.util.ColorUtil.getBgContrast (this.bgRgb) == 8 ? 4 : 8) : colorIndex == -6 ? J.util.ColorUtil.getBgContrast (this.bgRgb) : J.util.C.getColixO (Integer.$valueOf (J.adapter.readers.pymol.PyMOL.getRGB (colorIndex))));
return J.util.C.getColixTranslucent3 (colix, translucency > 0, translucency);
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.colorSettingClamped = $_M(c$, "colorSettingClamped", 
($fz = function (c) {
return (c.size () < 6 || J.adapter.readers.pymol.PyMOLReader.intAt (c, 4) == 0 ? J.adapter.readers.pymol.PyMOLReader.colorSetting (c) : J.adapter.readers.pymol.PyMOLReader.getColorPt (c.get (5)));
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
c$.getColorPt = $_M(c$, "getColorPt", 
($fz = function (o) {
return (Clazz.instanceOf (o, Integer) ? (o).intValue () : J.util.ColorUtil.colorPtToInt (J.adapter.readers.pymol.PyMOLReader.pointAt (o, 0, J.adapter.readers.pymol.PyMOLReader.ptTemp)));
}, $fz.isPrivate = true, $fz), "~O");
c$.colorSetting = $_M(c$, "colorSetting", 
($fz = function (c) {
return J.adapter.readers.pymol.PyMOLReader.getColorPt (c.get (2));
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
c$.intAt = $_M(c$, "intAt", 
($fz = function (list, i) {
return (list.get (i)).intValue ();
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N");
c$.floatAt = $_M(c$, "floatAt", 
function (list, i) {
return (list == null ? 0 : (list.get (i)).floatValue ());
}, "J.util.JmolList,~N");
c$.pointAt = $_M(c$, "pointAt", 
function (list, i, pt) {
pt.set (J.adapter.readers.pymol.PyMOLReader.floatAt (list, i++), J.adapter.readers.pymol.PyMOLReader.floatAt (list, i++), J.adapter.readers.pymol.PyMOLReader.floatAt (list, i));
return pt;
}, "J.util.JmolList,~N,J.util.P3");
c$.stringAt = $_M(c$, "stringAt", 
($fz = function (list, i) {
var s = list.get (i).toString ();
return (s.length == 0 ? " " : s);
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N");
c$.floatsAt = $_M(c$, "floatsAt", 
($fz = function (a, pt, data, len) {
if (a == null) return null;
for (var i = 0; i < len; i++) data[i] = J.adapter.readers.pymol.PyMOLReader.floatAt (a, pt++);

return data;
}, $fz.isPrivate = true, $fz), "J.util.JmolList,~N,~A,~N");
c$.listAt = $_M(c$, "listAt", 
function (list, i) {
if (list == null || i >= list.size ()) return null;
var o = list.get (i);
return (Clazz.instanceOf (o, J.util.JmolList) ? o : null);
}, "J.util.JmolList,~N");
c$.getMapList = $_M(c$, "getMapList", 
($fz = function (map, key) {
return map.get (key);
}, $fz.isPrivate = true, $fz), "java.util.Map,~S");
c$.fixName = $_M(c$, "fixName", 
($fz = function (name) {
var chars = name.toLowerCase ().toCharArray ();
for (var i = chars.length; --i >= 0; ) if (!Character.isLetterOrDigit (chars[i])) chars[i] = '_';

return String.valueOf (chars);
}, $fz.isPrivate = true, $fz), "~S");
c$.getBsReps = $_M(c$, "getBsReps", 
($fz = function (list) {
var bsReps =  new J.util.BS ();
for (var i = 0; i < 12; i++) if (J.adapter.readers.pymol.PyMOLReader.intAt (list, i) == 1) bsReps.set (i);

return bsReps;
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
c$.getBranchType = $_M(c$, "getBranchType", 
($fz = function (branch) {
return J.adapter.readers.pymol.PyMOLReader.intAt (branch, 4);
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
c$.getBranchAtoms = $_M(c$, "getBranchAtoms", 
($fz = function (deepBranch) {
return J.adapter.readers.pymol.PyMOLReader.listAt (deepBranch, 7);
}, $fz.isPrivate = true, $fz), "J.util.JmolList");
Clazz.defineStatics (c$,
"REP_JMOL_TRACE", 13,
"REP_JMOL_PUTTY", 14,
"REP_JMOL_MAX", 15,
"BRANCH_SELECTION", -1,
"BRANCH_MOLECULE", 1,
"BRANCH_MAPDATA", 2,
"BRANCH_MAPMESH", 3,
"BRANCH_MEASURE", 4,
"BRANCH_CALLBACK", 5,
"BRANCH_CGO", 6,
"BRANCH_SURFACE", 7,
"BRANCH_GADGET", 8,
"BRANCH_CALCULATOR", 9,
"BRANCH_SLICE", 10,
"BRANCH_ALIGNMENT", 11,
"BRANCH_GROUP", 12,
"MIN_RESNO", -1000,
"nucleic", " A C G T U ADE THY CYT GUA URI DA DC DG DT DU ");
c$.ptTemp = c$.prototype.ptTemp =  new J.util.P3 ();
Clazz.defineStatics (c$,
"MEAS_DIGITS", [530, 531, 532]);
});
