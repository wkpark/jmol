﻿$_L(["$wt.internal.SWTEventListener"],"$wt.custom.VerifyKeyListener",null,function(){
$_I($wt.custom,"VerifyKeyListener",$wt.internal.SWTEventListener);
});
