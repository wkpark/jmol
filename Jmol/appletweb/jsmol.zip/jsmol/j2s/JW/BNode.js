Clazz.declarePackage ("JW");
Clazz.load (["JW.Node"], "JW.BNode", null, function () {
Clazz.declareInterface (JW, "BNode", JW.Node);
});
