Clazz.declarePackage ("J.api");
Clazz.load (["J.api.JmolGraphicsInterface"], "J.api.JmolRendererInterface", null, function () {
Clazz.declareInterface (J.api, "JmolRendererInterface", J.api.JmolGraphicsInterface);
});
