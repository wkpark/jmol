$_L(["java.lang.RuntimeException"],"java.lang.SecurityException",null,function(){
c$=$_T(java.lang,"SecurityException",RuntimeException);
$_K(c$,
function(cause){
$_R(this,SecurityException,[(cause==null?null:cause.toString()),cause]);
},"Throwable");
});
