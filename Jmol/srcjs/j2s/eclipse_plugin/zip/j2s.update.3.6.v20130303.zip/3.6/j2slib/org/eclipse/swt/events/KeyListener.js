﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.KeyListener",null,function(){
$_I($wt.events,"KeyListener",$wt.internal.SWTEventListener);
});
