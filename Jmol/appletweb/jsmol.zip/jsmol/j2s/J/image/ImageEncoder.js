Clazz.declarePackage ("J.image");
Clazz.load (null, "J.image.ImageEncoder", ["J.api.Interface"], function () {
c$ = Clazz.decorateAsClass (function () {
this.out = null;
this.width = -1;
this.height = -1;
this.pixels = null;
Clazz.instantialize (this, arguments);
}, J.image, "ImageEncoder");
c$.write = $_M(c$, "write", 
function (apiPlatform, type, objImage, out, params, errRet) {
var ie = J.api.Interface.getInterface ("J.image." + type + "Encoder");
if (ie == null) {
errRet[0] = "Image encoder type " + type + " not available";
return false;
}ie.encode (apiPlatform, objImage, out, params);
try {
ie.createImage ();
} catch (e) {
if (Clazz.exceptionOf (e, java.io.IOException)) {
errRet[0] = e.toString ();
out.cancel ();
return false;
} else {
throw e;
}
} finally {
ie.close ();
}
return true;
}, "J.api.ApiPlatform,~S,~O,J.io.JmolOutputChannel,java.util.Map,~A");
$_M(c$, "encode", 
($fz = function (apiPlatform, objImage, out, params) {
this.out = out;
this.setParams (params);
this.width = apiPlatform.getImageWidth (objImage);
this.height = apiPlatform.getImageHeight (objImage);
{
pixels = null;
}this.pixels = apiPlatform.grabPixels (objImage, this.width, this.height, this.pixels, 0, this.height);
}, $fz.isPrivate = true, $fz), "J.api.ApiPlatform,~O,J.io.JmolOutputChannel,java.util.Map");
$_M(c$, "close", 
function () {
this.out.closeChannel ();
});
$_M(c$, "putString", 
function (str) {
this.out.append (str);
}, "~S");
$_M(c$, "putByte", 
function (b) {
this.out.writeByteAsInt (b);
}, "~N");
});
