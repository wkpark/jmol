Clazz.declarePackage ("JZ");
Clazz.load (["java.io.IOException"], "JZ.GZIPException", null, function () {
c$ = Clazz.declareType (JZ, "GZIPException", java.io.IOException);
});
