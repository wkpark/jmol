$_J("net.sf.j2s.ajax");
$_L(["net.sf.j2s.ajax.SimpleSerializable"],"net.sf.j2s.ajax.CompoundSerializable",null,function(){
c$=$_C(function(){
this.session=null;
$_Z(this,arguments);
},net.sf.j2s.ajax,"CompoundSerializable",net.sf.j2s.ajax.SimpleSerializable);
$_s(c$,"session","s");
});
