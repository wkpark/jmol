___date="$Date: 2013-10-30 10:25:32 -0500 (Wed, 30 Oct 2013) $"
___svnRev="$LastChangedRevision: 1393 $"
___version="2.1.0"
___JmolVersion="13.3.7_dev_2013.10.09"
Clazz.declarePackage ("JSV.common");
c$ = Clazz.declareType (JSV.common, "JSVersion");
Clazz.defineStatics (c$,
"VERSION", null,
"VERSION_SHORT", null);
{
var tmpVersion = null;
var tmpDate = null;
var tmpSVN = null;
{
tmpVersion = self.___version; tmpDate = self.___date; tmpSVN =
self.___svnRev;
}if (tmpDate != null) tmpDate = tmpDate.substring (7, 23);
if (tmpSVN != null) tmpSVN = tmpSVN.substring (22, 27);
($t$ = JSV.common.JSVersion.VERSION_SHORT = (tmpVersion != null ? tmpVersion : "(Unknown version)"), JSV.common.JSVersion.prototype.VERSION_SHORT = JSV.common.JSVersion.VERSION_SHORT, $t$);
($t$ = JSV.common.JSVersion.VERSION = JSV.common.JSVersion.VERSION_SHORT + "/SVN" + tmpSVN + "/" + (tmpDate != null ? tmpDate : "(Unknown date)"), JSV.common.JSVersion.prototype.VERSION = JSV.common.JSVersion.VERSION, $t$);
}