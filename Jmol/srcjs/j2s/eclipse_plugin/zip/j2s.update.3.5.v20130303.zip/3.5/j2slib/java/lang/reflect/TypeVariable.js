﻿$_L(["java.lang.reflect.Type"],"java.lang.reflect.TypeVariable",null,function(){
$_I(java.lang.reflect,"TypeVariable",java.lang.reflect.Type);
});
