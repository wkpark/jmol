$_L(["java.io.IOException"],"java.io.EOFException",null,function(){
c$=$_T(java.io,"EOFException",java.io.IOException);
});
