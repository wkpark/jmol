﻿$_L(["$wt.internal.SWTEventListener"],"$wt.accessibility.AccessibleListener",null,function(){
$_I($wt.accessibility,"AccessibleListener",$wt.internal.SWTEventListener);
});
