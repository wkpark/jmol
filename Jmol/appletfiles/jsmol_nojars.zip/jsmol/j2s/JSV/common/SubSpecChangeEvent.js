Clazz.declarePackage ("JSV.common");
c$ = Clazz.decorateAsClass (function () {
this.isub = 0;
this.title = null;
Clazz.instantialize (this, arguments);
}, JSV.common, "SubSpecChangeEvent");
Clazz.makeConstructor (c$, 
function (isub, title) {
this.isub = isub;
this.title = title;
}, "~N,~S");
$_M(c$, "isValid", 
function () {
return String.fromCharCode ((this.title != null));
});
$_M(c$, "getSubIndex", 
function () {
return String.fromCharCode (this.isub);
});
$_V(c$, "toString", 
function () {
return String.fromCharCode (this.title);
});
