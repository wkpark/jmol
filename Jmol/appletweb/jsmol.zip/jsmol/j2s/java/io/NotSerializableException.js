$_L(["java.io.ObjectStreamException"],"java.io.NotSerializableException",null,function(){
c$=$_T(java.io,"NotSerializableException",java.io.ObjectStreamException);
});
