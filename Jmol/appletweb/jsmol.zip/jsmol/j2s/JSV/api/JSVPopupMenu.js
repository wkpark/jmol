Clazz.declarePackage ("JSV.api");
Clazz.load (["J.api.GenericMenuInterface"], "JSV.api.JSVPopupMenu", null, function () {
Clazz.declareInterface (JSV.api, "JSVPopupMenu", J.api.GenericMenuInterface);
});
