﻿$_L(["$wt.events.TypedEvent"],"$wt.custom.CTabFolderEvent",null,function(){
c$=$_C(function(){
this.item=null;
this.doit=false;
this.x=0;
this.y=0;
this.width=0;
this.height=0;
$_Z(this,arguments);
},$wt.custom,"CTabFolderEvent",$wt.events.TypedEvent);
$_M(c$,"toString",
function(){
var string=$_U(this,$wt.custom.CTabFolderEvent,"toString",[]);
return string.substring(0,string.length-1)+" item="+this.item+" doit="+this.doit+" x="+this.x+" y="+this.y+" width="+this.width+" height="+this.height+"}";
});
});
