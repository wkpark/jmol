Clazz.declarePackage ("JW");
Clazz.declareInterface (JW, "LoggerInterface");
