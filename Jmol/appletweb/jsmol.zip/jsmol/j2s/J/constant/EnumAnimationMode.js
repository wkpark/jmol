Clazz.declarePackage ("J.constant");
Clazz.load (["java.lang.Enum"], "J.constant.EnumAnimationMode", null, function () {
c$ = Clazz.declareType (J.constant, "EnumAnimationMode", Enum);
Clazz.defineEnumConstant (c$, "ONCE", 0, []);
Clazz.defineEnumConstant (c$, "LOOP", 1, []);
Clazz.defineEnumConstant (c$, "PALINDROME", 2, []);
});
