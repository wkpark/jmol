﻿$_L(["java.io.ObjectStreamException"],"java.io.OptionalDataException",null,function(){
c$=$_C(function(){
this.eof=false;
this.length=0;
$_Z(this,arguments);
},java.io,"OptionalDataException",java.io.ObjectStreamException);
});
