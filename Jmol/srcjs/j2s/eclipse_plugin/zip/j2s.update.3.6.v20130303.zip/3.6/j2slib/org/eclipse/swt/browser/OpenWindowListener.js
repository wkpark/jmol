﻿$_L(["$wt.internal.SWTEventListener"],"$wt.browser.OpenWindowListener",null,function(){
$_I($wt.browser,"OpenWindowListener",$wt.internal.SWTEventListener);
});
