$_L(["java.lang.VirtualMachineError"],"java.lang.StackOverflowError",null,function(){
c$=$_T(java.lang,"StackOverflowError",VirtualMachineError);
});
