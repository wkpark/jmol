﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.ShellListener",null,function(){
$_I($wt.events,"ShellListener",$wt.internal.SWTEventListener);
});
