Clazz.declarePackage ("J.api");
c$ = Clazz.declareType (J.api, "JmolAdapterAtomIterator");
$_M(c$, "getAtomSetIndex", 
function () {
return 0;
});
$_M(c$, "getAtomSymmetry", 
function () {
return null;
});
$_M(c$, "getAtomSite", 
function () {
return -2147483648;
});
$_M(c$, "getElementNumber", 
function () {
return -1;
});
$_M(c$, "getAtomName", 
function () {
return null;
});
$_M(c$, "getFormalCharge", 
function () {
return 0;
});
$_M(c$, "getPartialCharge", 
function () {
return NaN;
});
$_M(c$, "getEllipsoid", 
function () {
return null;
});
$_M(c$, "getRadius", 
function () {
return NaN;
});
$_M(c$, "getVectorX", 
function () {
return NaN;
});
$_M(c$, "getVectorY", 
function () {
return NaN;
});
$_M(c$, "getVectorZ", 
function () {
return NaN;
});
$_M(c$, "getBfactor", 
function () {
return NaN;
});
$_M(c$, "getOccupancy", 
function () {
return 100;
});
$_M(c$, "getIsHetero", 
function () {
return false;
});
$_M(c$, "getAtomSerial", 
function () {
return -2147483648;
});
$_M(c$, "getChainID", 
function () {
return '\0';
});
$_M(c$, "getAlternateLocationID", 
function () {
return '\0';
});
$_M(c$, "getGroup3", 
function () {
return null;
});
$_M(c$, "getSequenceNumber", 
function () {
return -2147483648;
});
$_M(c$, "getInsertionCode", 
function () {
return '\0';
});
