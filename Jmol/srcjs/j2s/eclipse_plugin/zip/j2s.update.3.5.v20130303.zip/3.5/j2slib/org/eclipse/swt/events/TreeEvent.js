﻿$_L(["$wt.events.SelectionEvent"],"$wt.events.TreeEvent",null,function(){
c$=$_T($wt.events,"TreeEvent",$wt.events.SelectionEvent);
});
