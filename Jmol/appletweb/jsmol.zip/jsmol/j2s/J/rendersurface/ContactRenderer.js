Clazz.declarePackage ("J.rendersurface");
Clazz.load (["J.rendersurface.IsosurfaceRenderer"], "J.rendersurface.ContactRenderer", null, function () {
c$ = Clazz.declareType (J.rendersurface, "ContactRenderer", J.rendersurface.IsosurfaceRenderer);
});
